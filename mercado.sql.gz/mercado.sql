--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = true;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: webnobre; Tablespace: 
--

CREATE TABLE categories (
    category_id integer NOT NULL,
    name text NOT NULL,
    status integer NOT NULL,
    date_add date,
    date_update date,
    date_delete date
);


ALTER TABLE public.categories OWNER TO webnobre;

--
-- Name: categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: webnobre
--

CREATE SEQUENCE categories_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.categories_category_id_seq OWNER TO webnobre;

--
-- Name: categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webnobre
--

ALTER SEQUENCE categories_category_id_seq OWNED BY categories.category_id;


--
-- Name: categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webnobre
--

SELECT pg_catalog.setval('categories_category_id_seq', 6, true);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: webnobre; Tablespace: 
--

CREATE TABLE orders (
    order_id integer NOT NULL,
    customer_id integer,
    customer_name text,
    customer_email text,
    customer_document text,
    customer_telephone text,
    customer_address text,
    customer_address_num text,
    customer_address_district text,
    customer_address_city text,
    customer_address_zone text,
    customer_address_zip text,
    qnt_items integer NOT NULL,
    subtotal numeric(15,4) NOT NULL,
    tax numeric(15,4) NOT NULL,
    total numeric(15,4) NOT NULL,
    payment_method text NOT NULL,
    status integer NOT NULL,
    date_add date NOT NULL,
    date_delete date
);


ALTER TABLE public.orders OWNER TO webnobre;

--
-- Name: order_order_id_seq; Type: SEQUENCE; Schema: public; Owner: webnobre
--

CREATE SEQUENCE order_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.order_order_id_seq OWNER TO webnobre;

--
-- Name: order_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webnobre
--

ALTER SEQUENCE order_order_id_seq OWNED BY orders.order_id;


--
-- Name: order_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webnobre
--

SELECT pg_catalog.setval('order_order_id_seq', 33, true);


--
-- Name: order_products; Type: TABLE; Schema: public; Owner: webnobre; Tablespace: 
--

CREATE TABLE order_products (
    order_product_id integer NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    name text NOT NULL,
    ean text NOT NULL,
    quantity integer NOT NULL,
    price numeric(15,4) NOT NULL,
    tax numeric(15,4) NOT NULL,
    total numeric(15,4) NOT NULL
);


ALTER TABLE public.order_products OWNER TO webnobre;

--
-- Name: order_product_order_product_id_seq; Type: SEQUENCE; Schema: public; Owner: webnobre
--

CREATE SEQUENCE order_product_order_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.order_product_order_product_id_seq OWNER TO webnobre;

--
-- Name: order_product_order_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webnobre
--

ALTER SEQUENCE order_product_order_product_id_seq OWNED BY order_products.order_product_id;


--
-- Name: order_product_order_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webnobre
--

SELECT pg_catalog.setval('order_product_order_product_id_seq', 16, true);


--
-- Name: product_types; Type: TABLE; Schema: public; Owner: webnobre; Tablespace: 
--

CREATE TABLE product_types (
    product_type_id integer NOT NULL,
    name text NOT NULL,
    tax numeric(15,4) NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    date_add date,
    date_update date,
    date_delete date
);


ALTER TABLE public.product_types OWNER TO webnobre;

--
-- Name: product_types_product_type_id_seq; Type: SEQUENCE; Schema: public; Owner: webnobre
--

CREATE SEQUENCE product_types_product_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.product_types_product_type_id_seq OWNER TO webnobre;

--
-- Name: product_types_product_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webnobre
--

ALTER SEQUENCE product_types_product_type_id_seq OWNED BY product_types.product_type_id;


--
-- Name: product_types_product_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webnobre
--

SELECT pg_catalog.setval('product_types_product_type_id_seq', 6, true);


--
-- Name: products; Type: TABLE; Schema: public; Owner: webnobre; Tablespace: 
--

CREATE TABLE products (
    product_id integer NOT NULL,
    ean text NOT NULL,
    name text NOT NULL,
    un text NOT NULL,
    type integer NOT NULL,
    category integer NOT NULL,
    quantity integer NOT NULL,
    price numeric(15,4) NOT NULL,
    description text,
    status integer DEFAULT 0,
    date_add date NOT NULL,
    date_update date,
    date_delete date
);


ALTER TABLE public.products OWNER TO webnobre;

--
-- Name: products_product_id_seq; Type: SEQUENCE; Schema: public; Owner: webnobre
--

CREATE SEQUENCE products_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.products_product_id_seq OWNER TO webnobre;

--
-- Name: products_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webnobre
--

ALTER SEQUENCE products_product_id_seq OWNED BY products.product_id;


--
-- Name: products_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webnobre
--

SELECT pg_catalog.setval('products_product_id_seq', 14, true);


SET default_with_oids = false;

--
-- Name: users; Type: TABLE; Schema: public; Owner: webnobre; Tablespace: 
--

CREATE TABLE users (
    user_id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    flagadmin integer NOT NULL,
    status integer NOT NULL,
    date_add date,
    date_update date,
    date_delete date,
    last_login date,
    last_ip text
);


ALTER TABLE public.users OWNER TO webnobre;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: webnobre
--

CREATE SEQUENCE users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO webnobre;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webnobre
--

ALTER SEQUENCE users_user_id_seq OWNED BY users.user_id;


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webnobre
--

SELECT pg_catalog.setval('users_user_id_seq', 1, true);


--
-- Name: category_id; Type: DEFAULT; Schema: public; Owner: webnobre
--

ALTER TABLE ONLY categories ALTER COLUMN category_id SET DEFAULT nextval('categories_category_id_seq'::regclass);


--
-- Name: order_product_id; Type: DEFAULT; Schema: public; Owner: webnobre
--

ALTER TABLE ONLY order_products ALTER COLUMN order_product_id SET DEFAULT nextval('order_product_order_product_id_seq'::regclass);


--
-- Name: order_id; Type: DEFAULT; Schema: public; Owner: webnobre
--

ALTER TABLE ONLY orders ALTER COLUMN order_id SET DEFAULT nextval('order_order_id_seq'::regclass);


--
-- Name: product_type_id; Type: DEFAULT; Schema: public; Owner: webnobre
--

ALTER TABLE ONLY product_types ALTER COLUMN product_type_id SET DEFAULT nextval('product_types_product_type_id_seq'::regclass);


--
-- Name: product_id; Type: DEFAULT; Schema: public; Owner: webnobre
--

ALTER TABLE ONLY products ALTER COLUMN product_id SET DEFAULT nextval('products_product_id_seq'::regclass);


--
-- Name: user_id; Type: DEFAULT; Schema: public; Owner: webnobre
--

ALTER TABLE ONLY users ALTER COLUMN user_id SET DEFAULT nextval('users_user_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: webnobre
--

INSERT INTO categories VALUES (3, 'Categoria Teste', 1, '2023-07-07', NULL, NULL);
INSERT INTO categories VALUES (5, 'teste', 0, '2023-07-09', NULL, '2023-07-09');
INSERT INTO categories VALUES (6, 'Serviço', 1, '2023-07-10', NULL, NULL);


--
-- Data for Name: order_products; Type: TABLE DATA; Schema: public; Owner: webnobre
--

INSERT INTO order_products VALUES (10, 28, 6, 'BIOFRESH', '789898979799', 1, 1000.0000, 15.0000, 1015.0000);
INSERT INTO order_products VALUES (11, 28, 13, 'teste', '123', 1, 150.0000, 2.2500, 152.2500);
INSERT INTO order_products VALUES (12, 29, 6, 'BIOFRESH', '789898979799', 1, 1000.0000, 15.0000, 1015.0000);
INSERT INTO order_products VALUES (13, 30, 6, 'BIOFRESH', '789898979799', 1, 1000.0000, 15.0000, 1015.0000);
INSERT INTO order_products VALUES (14, 31, 6, 'BIOFRESH', '789898979799', 1, 1000.0000, 15.0000, 1015.0000);
INSERT INTO order_products VALUES (15, 32, 6, 'BIOFRESH', '789898979799', 11, 1000.0000, 165.0000, 11165.0000);
INSERT INTO order_products VALUES (16, 33, 14, 'Manutenção a micro informatica', '7890000000', 1, 3000.0000, 450.0000, 3450.0000);


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: webnobre
--

INSERT INTO orders VALUES (28, NULL, 'wender', '', '728.444.261-15', '', '', '', '', '', '', '', 2, 1150.0000, 17.2500, 1167.2500, 'Dinheiro', 1, '2023-07-09', NULL);
INSERT INTO orders VALUES (29, NULL, '', '', '', '', '', '', '', '', '', '', 1, 1000.0000, 15.0000, 1015.0000, 'Dinheiro', 1, '2023-07-09', NULL);
INSERT INTO orders VALUES (30, NULL, '', '', '', '', '', '', '', '', '', '', 1, 1000.0000, 15.0000, 1015.0000, 'Dinheiro', 1, '2023-07-09', NULL);
INSERT INTO orders VALUES (31, NULL, '', '', '', '', '', '', '', '', '', '', 1, 1000.0000, 15.0000, 1015.0000, 'Dinheiro', 1, '2023-07-09', NULL);
INSERT INTO orders VALUES (32, NULL, 'wender afonso martins', 'wammachado@gmail.com', '728.444.261-15', '(62) 99579-8343', 'rua tal', '0', 'bairro', 'cidade alem', 'rj', '22763-145', 11, 11000.0000, 165.0000, 11165.0000, 'Dinheiro', 1, '2023-07-10', NULL);
INSERT INTO orders VALUES (33, NULL, 'JOAO PEÇANHA', 'email@email.com', '042.022.222-22', '(21) 99999-9999', '', '', '', '', '', '', 1, 3000.0000, 450.0000, 3450.0000, 'PIX', 1, '2023-07-10', NULL);


--
-- Data for Name: product_types; Type: TABLE DATA; Schema: public; Owner: webnobre
--

INSERT INTO product_types VALUES (5, 'TESTE', 10.0000, 0, '2023-07-09', NULL, '2023-07-09');
INSERT INTO product_types VALUES (1, 'Mercadoria para Revenda', 1.5000, 1, '2023-07-06', '2023-07-09', NULL);
INSERT INTO product_types VALUES (4, 'Ativo Imobilizado', 1.5000, 1, '2023-07-07', '2023-07-09', NULL);
INSERT INTO product_types VALUES (6, 'Serviço', 15.0000, 1, '2023-07-10', NULL, NULL);


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: webnobre
--

INSERT INTO products VALUES (6, '789898979799', 'BIOFRESH', 'UN', 4, 4, 11, 1000.0000, 'etste', 1, '2023-07-06', '2023-07-07', NULL);
INSERT INTO products VALUES (7, '7896588940905', 'azgo', 'UN', 1, 3, 1, 20.0000, '', 0, '2023-07-06', '2023-07-07', '2023-07-09');
INSERT INTO products VALUES (13, '123', 'teste', 'UN', 4, 3, 20, 150.0000, 'teste', 1, '2023-07-09', '2023-07-09', NULL);
INSERT INTO products VALUES (14, '7890000000', 'Manutenção a micro informatica', 'UN', 6, 6, 1, 3000.0000, 'Manutenção a micro informatica', 1, '2023-07-10', '2023-07-10', NULL);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: webnobre
--

INSERT INTO users VALUES (1, 'Wender', 'wammachado@gmail.com', '$2y$10$kTXDT52b4ifUDBtsEJJrAebEwcC5anbTleyo2DkZJ.AhttwfPNaIK', 1, 1, '2023-07-06', NULL, NULL, '2023-07-09', '186.205.8.31');


--
-- Name: categories_pkey; Type: CONSTRAINT; Schema: public; Owner: webnobre; Tablespace: 
--

ALTER TABLE ONLY categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (category_id);


--
-- Name: order_pkey; Type: CONSTRAINT; Schema: public; Owner: webnobre; Tablespace: 
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT order_pkey PRIMARY KEY (order_id);


--
-- Name: order_product_pkey; Type: CONSTRAINT; Schema: public; Owner: webnobre; Tablespace: 
--

ALTER TABLE ONLY order_products
    ADD CONSTRAINT order_product_pkey PRIMARY KEY (order_product_id);


--
-- Name: product_types_pkey; Type: CONSTRAINT; Schema: public; Owner: webnobre; Tablespace: 
--

ALTER TABLE ONLY product_types
    ADD CONSTRAINT product_types_pkey PRIMARY KEY (product_type_id);


--
-- Name: products_pkey; Type: CONSTRAINT; Schema: public; Owner: webnobre; Tablespace: 
--

ALTER TABLE ONLY products
    ADD CONSTRAINT products_pkey PRIMARY KEY (product_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: categories; Type: ACL; Schema: public; Owner: webnobre
--

REVOKE ALL ON TABLE categories FROM PUBLIC;
REVOKE ALL ON TABLE categories FROM webnobre;
GRANT ALL ON TABLE categories TO webnobre;
GRANT ALL ON TABLE categories TO webnobre_userprova;
GRANT ALL ON TABLE categories TO webnobre_prova;


--
-- Name: categories_category_id_seq; Type: ACL; Schema: public; Owner: webnobre
--

REVOKE ALL ON SEQUENCE categories_category_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE categories_category_id_seq FROM webnobre;
GRANT ALL ON SEQUENCE categories_category_id_seq TO webnobre;
GRANT ALL ON SEQUENCE categories_category_id_seq TO webnobre_userprova;
GRANT ALL ON SEQUENCE categories_category_id_seq TO webnobre_prova;


--
-- Name: orders; Type: ACL; Schema: public; Owner: webnobre
--

REVOKE ALL ON TABLE orders FROM PUBLIC;
REVOKE ALL ON TABLE orders FROM webnobre;
GRANT ALL ON TABLE orders TO webnobre;
GRANT ALL ON TABLE orders TO webnobre_userprova;
GRANT ALL ON TABLE orders TO webnobre_prova;


--
-- Name: order_order_id_seq; Type: ACL; Schema: public; Owner: webnobre
--

REVOKE ALL ON SEQUENCE order_order_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE order_order_id_seq FROM webnobre;
GRANT ALL ON SEQUENCE order_order_id_seq TO webnobre;
GRANT ALL ON SEQUENCE order_order_id_seq TO webnobre_userprova;
GRANT ALL ON SEQUENCE order_order_id_seq TO webnobre_prova;


--
-- Name: order_products; Type: ACL; Schema: public; Owner: webnobre
--

REVOKE ALL ON TABLE order_products FROM PUBLIC;
REVOKE ALL ON TABLE order_products FROM webnobre;
GRANT ALL ON TABLE order_products TO webnobre;
GRANT ALL ON TABLE order_products TO webnobre_userprova;
GRANT ALL ON TABLE order_products TO webnobre_prova;


--
-- Name: order_product_order_product_id_seq; Type: ACL; Schema: public; Owner: webnobre
--

REVOKE ALL ON SEQUENCE order_product_order_product_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE order_product_order_product_id_seq FROM webnobre;
GRANT ALL ON SEQUENCE order_product_order_product_id_seq TO webnobre;
GRANT ALL ON SEQUENCE order_product_order_product_id_seq TO webnobre_userprova;
GRANT ALL ON SEQUENCE order_product_order_product_id_seq TO webnobre_prova;


--
-- Name: product_types; Type: ACL; Schema: public; Owner: webnobre
--

REVOKE ALL ON TABLE product_types FROM PUBLIC;
REVOKE ALL ON TABLE product_types FROM webnobre;
GRANT ALL ON TABLE product_types TO webnobre;
GRANT ALL ON TABLE product_types TO webnobre_userprova;
GRANT ALL ON TABLE product_types TO webnobre_prova;


--
-- Name: product_types.product_type_id; Type: ACL; Schema: public; Owner: webnobre
--

REVOKE ALL(product_type_id) ON TABLE product_types FROM PUBLIC;
REVOKE ALL(product_type_id) ON TABLE product_types FROM webnobre;
GRANT ALL(product_type_id) ON TABLE product_types TO webnobre;
GRANT ALL(product_type_id) ON TABLE product_types TO webnobre_userprova;
GRANT ALL(product_type_id) ON TABLE product_types TO webnobre_prova;
GRANT ALL(product_type_id) ON TABLE product_types TO PUBLIC;


--
-- Name: product_types_product_type_id_seq; Type: ACL; Schema: public; Owner: webnobre
--

REVOKE ALL ON SEQUENCE product_types_product_type_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE product_types_product_type_id_seq FROM webnobre;
GRANT ALL ON SEQUENCE product_types_product_type_id_seq TO webnobre;
GRANT ALL ON SEQUENCE product_types_product_type_id_seq TO webnobre_userprova;
GRANT ALL ON SEQUENCE product_types_product_type_id_seq TO webnobre_prova;


--
-- Name: products; Type: ACL; Schema: public; Owner: webnobre
--

REVOKE ALL ON TABLE products FROM PUBLIC;
REVOKE ALL ON TABLE products FROM webnobre;
GRANT ALL ON TABLE products TO webnobre;
GRANT ALL ON TABLE products TO webnobre_prova;
GRANT ALL ON TABLE products TO PUBLIC;
GRANT ALL ON TABLE products TO webnobre_userprova;


--
-- Name: products_product_id_seq; Type: ACL; Schema: public; Owner: webnobre
--

REVOKE ALL ON SEQUENCE products_product_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE products_product_id_seq FROM webnobre;
GRANT ALL ON SEQUENCE products_product_id_seq TO webnobre;
GRANT ALL ON SEQUENCE products_product_id_seq TO PUBLIC;
GRANT ALL ON SEQUENCE products_product_id_seq TO webadega;
GRANT ALL ON SEQUENCE products_product_id_seq TO webnobre_userprova;
GRANT ALL ON SEQUENCE products_product_id_seq TO webnobre_prova;


--
-- Name: users; Type: ACL; Schema: public; Owner: webnobre
--

REVOKE ALL ON TABLE users FROM PUBLIC;
REVOKE ALL ON TABLE users FROM webnobre;
GRANT ALL ON TABLE users TO webnobre;
GRANT ALL ON TABLE users TO webnobre_prova;


--
-- PostgreSQL database dump complete
--

